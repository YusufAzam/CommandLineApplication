import org.apache.commons.cli.*;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;


import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.math.BigInteger;
import java.nio.file.Files;
import java.security.MessageDigest;


/**
 * @author Yusuf Jamal Azam
 */

public class CommandLineApp {
    static FileUtils file = new FileUtils();

    /**
     * Checks to see if the file is a pdf by
     * using the first Hex values from the FileInputStream.
     * This works as Java breaks it down into bytes
     * @param file
     * @return
     * @throws IOException
     */
    public static boolean isPdf(File file) throws IOException {
        //The Hexcadecimal values converted into regular decimals
        int [] pdf = {37,80,68,70};
        FileInputStream input = new FileInputStream(file);
        byte[] keyBytes = Files.readAllBytes(file.toPath());

        //System.out.println(file.getName());
        if(keyBytes.length<3){
            return false;
        }

        for(int i=0;i<=3;i++){
            if(pdf[i] != keyBytes[i]){
                return false;
            }

        }

        return true;
    }

    /**
     * Checks to see if file is a Jpeg file
     * @param file
     * @return
     * @throws IOException
     */
    public static boolean isJpeg(File file) throws IOException{

        //The Hexcadecimal values converted into two's complement
        int [] jpeg = {-1,-40};
        FileInputStream input = new FileInputStream(file);
        byte[] keyBytes = Files.readAllBytes(file.toPath());

        if(keyBytes.length<1){
            return false;
        }

        for(int i=0;i<=1;i++){
            if(jpeg[i] != keyBytes[i]){
                return false;
            }

        }
        return true;
    }

    /**
     * Writes PDF file to csv taking in the path of the pdf and
     * the path of the csv. It also uses the MD5 to write to the csv
     * Note it will not read word by word but rather line by line
     * @param pdfPath
     * @param path
     */
    static public void writeToFilePDF(String pdfPath,String path) {
        //Need to change path
        try{
            //Path of CSV file and Print writers to write to it
            FileWriter fileWriter = new FileWriter(path);
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.printf(path);
            printWriter.append(System.lineSeparator());
            printWriter.printf("PDF");
            printWriter.append(System.lineSeparator());

            //Reads text content of PDf file
            PDDocument document = PDDocument.load(new File(pdfPath));
            document.getClass();

            //As long as our PDF file is not Encrypted we can string it down line by line
            if(!document.isEncrypted()){
                PDFTextStripperByArea stripper = new PDFTextStripperByArea();
                stripper.setSortByPosition(true);

                PDFTextStripper Tstrip = new PDFTextStripper();
                String text = Tstrip.getText(document);
                String lines[] = text.split("\\r?\\n");

                //Generates line by line for reach MD5 hash
                MessageDigest md = MessageDigest.getInstance("MD5");
                for(int i=0;i<lines.length;i++){
                    byte[] messageDigest = md.digest(lines[i].getBytes());
                    BigInteger no = new BigInteger(1, messageDigest);
                    String hashtext = no.toString(16);
                    while (hashtext.length() < 32) {
                        hashtext = "0" + hashtext;
                    }
                    printWriter.printf(hashtext);
                    printWriter.append(System.lineSeparator());

                }
            }
            printWriter.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * Takes in two strings. The path to the Jpeg and the
     * path to the what will be the .csv file. Please note
     * you must name your file ending in .csv It will also
     * process the Jpeg and put every token separated by a space
     * @param pathJpeg
     * @param path
     */
    static public void writeToFileJpeg(String pathJpeg,String path){

        try{
            FileWriter fileWriter = new FileWriter(path);
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.printf(path);
            printWriter.append(System.lineSeparator());
            printWriter.printf("JPEG");
            printWriter.append(System.lineSeparator());


            File jpegFIle = new File(pathJpeg);
            BufferedImage image = ImageIO.read(jpegFIle);
            String imageByWord [] = image.toString().split(" ");

            MessageDigest md = MessageDigest.getInstance("MD5");
            for(int i=0;i<imageByWord.length;i++){
                byte[] messageDigest = md.digest(imageByWord[i].getBytes());
                BigInteger no = new BigInteger(1, messageDigest);
                String hashtext = no.toString(16);
                while (hashtext.length() < 32) {
                    hashtext = "0" + hashtext;
                }
                printWriter.printf(hashtext);
                printWriter.append(System.lineSeparator());

            }

            printWriter.close();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void writeToPdfRecursivly(File f,String PathForWrittenPdf){

        try{
            File [] contextsOfDirectory = f.listFiles();


            for(File files:contextsOfDirectory){

                System.out.println(files.getAbsolutePath().toString());

                if(!files.isDirectory() && isPdf(files)){

                    writeToFilePDF(files.getAbsolutePath(),PathForWrittenPdf);

                }else if(files.isDirectory()){

                }
            }

        }catch (Exception e){
            e.printStackTrace();;
        }

    }

    public static void writeToJpegRecursivly(File f,String pathtoCsv){

        try{

            File [] contentsOfDirectroy = f.listFiles();


            for(File files:contentsOfDirectroy){


                if(!files.isDirectory() && isJpeg(files)){
                    System.out.println("Jpeg found");
                    //args[2] += ".csv";
                    writeToFileJpeg(files.getAbsolutePath(),pathtoCsv);
                }else if(files.isDirectory()){
                    writeToJpegRecursivly(files,pathtoCsv);
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    /**
     * Main method the termin will take in Strings. This is what Java uses
     * for its main method. Hence string args[]. The directory and path are
     * then taken are parsed appropriately.
     * @param args
     * @throws ParseException
     */
    public static void main(String args[]) throws ParseException {

        //creating directory
        FilenameUtils name = new FilenameUtils();

        //We have two file filters. One will show files only
        //The other will also allow for subdirectory
        IOFileFilter filter = new IOFileFilter() {
            @Override
            public boolean accept(File file) {
                return true;
            }

            @Override
            public boolean accept(File file, String s) {
                return false;
            }
        };

        IOFileFilter f2 = new IOFileFilter() {
            @Override
            public boolean accept(File file) {
                return false;
            }

            @Override
            public boolean accept(File file, String s) {
                return false;
            }
        };


        //Options creates flags are allows for arugments to follow
        Options options = new Options();

        //Adding first options "-a" flag example
        //Order Flag Path argument
        options.addOption("a", true ,"Adds two options");
        options.addOption("dir", true, "Gets short directroy");
        options.addOption("dirsub",true,"gets full");
        options.addOption("base",true,"Shortens path");
        options.addOption("cpdf",true,"Reads file path and checks if is pdf");
        options.addOption("cjpeg",true,"Reads path and checks is jpeg");
        options.addOption("subpdf",true,"Includes subdirectories");
        options.addOption("subjpeg",true,"includes subdirectories");

        //Lets do some parsing
        CommandLineParser myParser = new DefaultParser();
        //Parsing options
        CommandLine cmd = myParser.parse(options, args);

        //Takes in a limit of two arguments
        //Others will throw an exception
        if(args.length>3){
            throw new IndexOutOfBoundsException("Only two arguments and a flag is allowed");
        }

        if (cmd.hasOption("dir")) {
            File f = new File(args[1]);
            System.out.println(file.listFiles(f,filter,f2));
        } else if (cmd.hasOption("dirsub")) {
            //Lists with Sub directories
            File f = new File(args[1]);
            System.out.println(file.listFiles(f,filter,filter));
        } else if(cmd.hasOption("base")){
            //This does not include the path but simimply lists
            //Sub directories.
            File f = new File(args[1]);
            for(File E:file.listFiles(f,filter,filter)){
                System.out.println(name.getBaseName(E.toString()));
            }
        } else if (cmd.hasOption("cpdf")){
            try{

                File f = new File(args[1]);
                File [] contentsOfDirectroy = f.listFiles();


                for(File files:contentsOfDirectroy){
                    if( !files.isDirectory() && isPdf(files)){
                        System.out.println("Pdf found");
                        //args[2] += ".csv";
                        writeToFilePDF(files.getAbsolutePath(),args[2]);
                    }else if(files.isDirectory()){
                        files.getAbsolutePath();

                    }
                }

            }catch (Exception e){
                e.printStackTrace();
            }
        }else if(cmd.hasOption("cjpeg")){
            try{
                File f = new File(args[1]);
                File [] contentsOfDirectroy = f.listFiles();


                for(File files:contentsOfDirectroy){


                    if(isJpeg(files)){
                        System.out.println("Jpeg found");
                        //args[2] += ".csv";
                        writeToFileJpeg(files.getAbsolutePath(),args[2]);
                    }else{
                        //System.out.println("File is not of type Jpeg");
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }else if(cmd.hasOption("subpdf")){
                try{
                    File f = new File(args[1]);
                    File [] contextsOfDirectory = f.listFiles();


                    for(File files:contextsOfDirectory){

                        if(!files.isDirectory() && isPdf(files)){
                          writeToFilePDF(files.getAbsolutePath(),args[2]);

                        }else if(files.isDirectory()){
                            //Here is the flaw in this. There may be more than one
                            //But inly one path
                            writeToPdfRecursivly(files,args[2]);
                        }
                    }

                }catch (Exception e){
                    e.printStackTrace();;
                }
            }else if(cmd.hasOption("subjpeg")){

            try{
                File f = new File(args[1]);
                File [] contentsOfDirectroy = f.listFiles();

                for(File files:contentsOfDirectroy){


                    if(!files.isDirectory() && isJpeg(files)){
                        System.out.println("Jpeg found");
                        //args[2] += ".csv";
                        writeToFileJpeg(files.getAbsolutePath(),args[2]);
                    }else if(files.isDirectory()){
                        writeToJpegRecursivly(files,args[2]);
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }


            }

        }
 }

