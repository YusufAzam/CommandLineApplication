How this commnad line app works.


dir - finds only directory and full path
subdir - fill find all subdirectories and files and return path
base - will return only file names

cpdf - creates a csv using a pdf. However if you have sub direcotires it will FAIL.
if that is the case you must use -subpdf. The same goes with the the -cjepf and -subjpeg

finally MD5 hash

for a pdf is hashes the line of text not word by word, unlike
the md5 for jpeg that will hash word by word.


Yusuf Azam